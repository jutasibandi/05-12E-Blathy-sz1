namespace Cukraszda
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dessertsMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutMenuItem;
        private System.Windows.Forms.PictureBox dessertPictureBox;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label invoiceLabel;
        private System.Windows.Forms.RichTextBox invoiceRichTextBox;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dessertsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dessertPictureBox = new System.Windows.Forms.PictureBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.invoiceLabel = new System.Windows.Forms.Label();
            this.invoiceRichTextBox = new System.Windows.Forms.RichTextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dessertPictureBox)).BeginInit();
            this.SuspendLayout();
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.fileMenuItem, this.dessertsMenuItem, this.aboutMenuItem });
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Size = new System.Drawing.Size(700, 24);

            this.fileMenuItem.Text = "Fájl";
            this.fileMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.loadMenuItem });

            this.loadMenuItem.Text = "Betöltés";
            this.loadMenuItem.Click += new System.EventHandler(this.LoadMenuItem_Click);

            this.dessertsMenuItem.Text = "Sütemények";
            this.dessertsMenuItem.Enabled = false;
            this.dessertsMenuItem.Click += new System.EventHandler(this.DessertsMenuItem_Click);

            this.aboutMenuItem.Text = "Névjegy";
            this.aboutMenuItem.Click += new System.EventHandler(this.AboutMenuItem_Click);
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.titleLabel.Location = new System.Drawing.Point(22, 38);
            this.titleLabel.Text = "Cukrászda";
            this.dessertPictureBox.Location = new System.Drawing.Point(25, 82);
            this.dessertPictureBox.Size = new System.Drawing.Size(300, 220);
            this.dessertPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dessertPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.invoiceLabel.AutoSize = true;
            this.invoiceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.invoiceLabel.Location = new System.Drawing.Point(355, 82);
            this.invoiceLabel.Text = "Számla";

            this.invoiceRichTextBox.Location = new System.Drawing.Point(355, 108);
            this.invoiceRichTextBox.Size = new System.Drawing.Size(315, 194);
            this.invoiceRichTextBox.ReadOnly = true;
            this.invoiceRichTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.invoiceRichTextBox.Text = "A számla a rendelés után, a rendelési ablakban\na Számlát kér menüponttal jeleníthető meg.";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 335);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.dessertPictureBox);
            this.Controls.Add(this.invoiceLabel);
            this.Controls.Add(this.invoiceRichTextBox);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cukrászda";

            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dessertPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
