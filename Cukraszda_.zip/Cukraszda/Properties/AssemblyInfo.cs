using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Cukraszda")]
[assembly: AssemblyDescription("Egyszerű cukrászda rendelőprogram")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Cukraszda")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("C34AF6E1-4F5B-43B2-9E6F-39BEFFB07C51")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
