namespace Cukraszda
{
    partial class OrderForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Panel dessertPanel;
        private System.Windows.Forms.Button orderButton;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem billMenuItem;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.titleLabel = new System.Windows.Forms.Label();
            this.dessertPanel = new System.Windows.Forms.Panel();
            this.orderButton = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.billMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SuspendLayout();

            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic);
            this.titleLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.titleLabel.Location = new System.Drawing.Point(145, 12);
            this.titleLabel.Text = "ÁRLISTA";

            this.dessertPanel.AutoScroll = true;
            this.dessertPanel.Location = new System.Drawing.Point(15, 52);
            this.dessertPanel.Size = new System.Drawing.Size(395, 210);

            this.orderButton.Location = new System.Drawing.Point(160, 280);
            this.orderButton.Size = new System.Drawing.Size(100, 30);
            this.orderButton.Text = "RENDEL";
            this.orderButton.UseVisualStyleBackColor = true;
            this.orderButton.Click += new System.EventHandler(this.OrderButton_Click);
            this.orderButton.ContextMenuStrip = this.contextMenuStrip1;

            this.billMenuItem.Text = "Számlát kér";
            this.billMenuItem.Click += new System.EventHandler(this.BillMenuItem_Click);
            this.contextMenuStrip1.Items.Add(this.billMenuItem);

            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 330);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.dessertPanel);
            this.Controls.Add(this.orderButton);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Sütemények";

            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
