namespace Cukraszda
{
    public class OrderItem
    {
        public string Name;
        public int Price;
        public int Quantity;

        public OrderItem(string name, int price, int quantity)
        {
            Name = name;
            Price = price;
            Quantity = quantity;
        }
    }
}
