namespace Cukraszda
{
    public class Dessert
    {
        public string Name;
        public int Price;

        public Dessert(string name, int price)
        {
            Name = name;
            Price = price;
        }
    }
}
