using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Cukraszda
{
    public partial class OrderForm : Form
    {
        private List<Dessert> desserts;
        private List<OrderItem> order;
        private List<CheckBox> checks = new List<CheckBox>();
        private List<NumericUpDown> amounts = new List<NumericUpDown>();

        public OrderForm(List<Dessert> dessertList, List<OrderItem> orderList)
        {
            InitializeComponent();
            desserts = dessertList;
            order = orderList;
            AddDesserts();
        }

        private void AddDesserts()
        {
            int y = 15;

            foreach (Dessert dessert in desserts)
            {
                CheckBox check = new CheckBox();
                check.Text = dessert.Name;
                check.Location = new System.Drawing.Point(18, y);
                check.Width = 180;

                Label price = new Label();
                price.Text = dessert.Price + " Ft";
                price.Location = new System.Drawing.Point(205, y + 3);
                price.Width = 70;

                NumericUpDown amount = new NumericUpDown();
                amount.Location = new System.Drawing.Point(285, y);
                amount.Width = 50;
                amount.Minimum = 1;
                amount.Maximum = 20;
                amount.Value = 1;

                Label unit = new Label();
                unit.Text = "adag";
                unit.Location = new System.Drawing.Point(345, y + 3);
                unit.Width = 45;

                dessertPanel.Controls.Add(check);
                dessertPanel.Controls.Add(price);
                dessertPanel.Controls.Add(amount);
                dessertPanel.Controls.Add(unit);

                checks.Add(check);
                amounts.Add(amount);
                y += 32;
            }
        }

        private void OrderButton_Click(object sender, EventArgs e)
        {
            bool vanKijelolve = false;

            for (int i = 0; i < checks.Count; i++)
            {
                if (checks[i].Checked)
                    vanKijelolve = true;
            }

            if (!vanKijelolve)
            {
                MessageBox.Show("Jelölj ki legalább egy süteményt!", "Hiba",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            for (int i = 0; i < checks.Count; i++)
            {
                if (checks[i].Checked)
                {
                    Dessert dessert = desserts[i];
                    int darab = (int)amounts[i].Value;
                    OrderItem existingItem = null;

                    foreach (OrderItem item in order)
                    {
                        if (item.Name == dessert.Name && item.Price == dessert.Price)
                        {
                            existingItem = item;
                            break;
                        }
                    }

                    if (existingItem == null)
                        order.Add(new OrderItem(dessert.Name, dessert.Price, darab));
                    else
                        existingItem.Quantity += darab;

                    checks[i].Checked = false;
                    amounts[i].Value = 1;
                }
            }

            MessageBox.Show("A rendelést rögzítettem.", "Rendelés",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BillMenuItem_Click(object sender, EventArgs e)
        {
            Form1 main = this.Owner as Form1;

            if (main != null)
                main.ShowInvoice();
        }
    }
}
